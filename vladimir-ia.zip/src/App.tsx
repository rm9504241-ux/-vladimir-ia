/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AnimatedAIChat } from "@/components/ui/animated-ai-chat";

export default function App() {
  return (
    <div className="min-h-screen bg-zinc-950 select-none">
      <AnimatedAIChat />
    </div>
  );
}
